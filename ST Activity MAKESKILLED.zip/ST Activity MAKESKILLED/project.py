import streamlit as st
import pandas as pd
import altair as alt
import datetime 

# Sample patient data (replace this with your actual data source)
patient_data = pd.read_csv('patient.csv')

# Sidebar - User Role Selection
user_role = st.sidebar.radio("Select User Role", ('Doctor', 'Nurse', 'Administrator'))

# Main content based on user role
st.title("Healthcare Analytics Platform")

# Display Patient Data
st.subheader("Patient Data")
st.dataframe(patient_data)

# Demographics Visualization
st.subheader("Demographics Visualization")

# Plot demographics using Altair
gender_chart = alt.Chart(patient_data).mark_bar().encode(
    x='Gender',
    y='count()',
    color='Gender'
).properties(
    width=400,
    height=300
)

st.altair_chart(gender_chart, use_container_width=True)

# Medical History and Medication Analysis
st.subheader("Medical History and Medication Analysis")

# Data Filtering based on user role (Dummy functionality, replace with actual logic)
if user_role == 'Doctor':
    selected_patient = st.selectbox("Select Patient", patient_data['Name'])
    selected_data = patient_data[patient_data['Name'] == selected_patient]
elif user_role == 'Nurse':
    selected_gender = st.selectbox("Select Gender", ['Male', 'Female'])
    selected_data = patient_data[patient_data['Gender'] == selected_gender]
else:
    selected_data = patient_data  # Administrator sees all data

# Display filtered data
st.dataframe(selected_data)

st.subheader("New Patient Registration")

# Real-time Updates (Dummy functionality, replace with actual real-time updates)
id=st.number_input('Enter Patient Id')
name=st.text_input('Enter Patient Name')
Gender=st.text_input('Enter gender')
Date_of_Birth=st.date_input('Enter Date of Birth',datetime.date(2004, 7, 6))
Medical_Condition=st.text_input('Enter medical condition')
Medication=st.text_input('Enter Medication')
Dosage=st.text_input('Enter dosage')
Last_Visit_Date=st.date_input('Enter last visit date')
if st.button("Register the Patient"):
    new_entry = pd.DataFrame({
        'Patient_ID': [id],
        'Name': [name],
        'Gender': [Gender],
        'Date_of_Birth': [Date_of_Birth],
        'Medical_Condition': [Medical_Condition],
        'Medication': [Medication],
        'Dosage': [Dosage],
        'Last_Visit_Date': [Last_Visit_Date]
    })
    patient_data = pd.concat([patient_data, new_entry], ignore_index=True)
    patient_data.to_csv('patient.csv',index = False)
    st.success("New entry added successfully!")
    st.rerun()

# Footer
st.text("© 2024 Healthcare Analytics Platform")
